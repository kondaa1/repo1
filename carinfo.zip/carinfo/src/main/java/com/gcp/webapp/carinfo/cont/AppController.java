package com.gcp.webapp.carinfo.cont;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.channels.Channels;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.ExecutionException;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.gcp.webapp.carinfo.model.Car;
import com.gcp.webapp.carinfo.service.FirebaseInitializer;
import com.google.api.core.ApiFuture;
import com.google.cloud.ReadChannel;
import com.google.cloud.firestore.CollectionReference;
import com.google.cloud.firestore.DocumentSnapshot;
import com.google.cloud.firestore.QuerySnapshot;
import com.google.cloud.storage.Blob;
import com.google.cloud.storage.Storage;

@RestController
public class AppController {
	
	public static HashMap<String,Car> map = new HashMap<>();

	@Autowired
	FirebaseInitializer db;

	@Autowired
	static Storage storage;
	static String bucket = "gcpwebappdb";

	@GetMapping(value = { "" })
	public ModelAndView index() throws InterruptedException, ExecutionException, IOException {
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("index");
		
		CollectionReference car = db.getFirebase().collection("car");
		File file = new File("./src/main/resources/static/downloadcarimages/");      
		FileUtils.cleanDirectory(file); 
		
		ApiFuture<QuerySnapshot> querySnapshot = car.get();
		for (DocumentSnapshot doc : querySnapshot.get().getDocuments()) {
			Car emp = doc.toObject(Car.class);
			AppController.map.put(emp.getModel().toUpperCase(), emp);		
			AppController.getImage(emp.getModel());

		}
		
		
		return modelAndView;
	}

	@RequestMapping(value = "getcarslist", method = RequestMethod.GET)
	public @ResponseBody List<Car> getCarsList(@RequestParam("company") String companyName)
			throws InterruptedException, ExecutionException {
		List<Car> carList = new ArrayList<Car>();
		CollectionReference car = db.getFirebase().collection("car");
		ApiFuture<QuerySnapshot> querySnapshot = car.get();
		for (DocumentSnapshot doc : querySnapshot.get().getDocuments()) {
			Car emp = doc.toObject(Car.class);
			if (emp.getCompany().equals(companyName)) {
				carList.add(emp);

			}
		}
		return carList;
	}

	@RequestMapping(value = "getcarinfo", method = RequestMethod.GET,produces="application/json")
	public Car getCarInfo(@RequestParam("name") String carName)
			throws InterruptedException, ExecutionException, IOException {
		System.out.print("getting details of: "+ carName);
		Car carobj = null;
		
		if(AppController.map.containsKey(carName.toUpperCase())) {
		//	AppController.getImage(carName);
			return AppController.map.get(carName.toUpperCase());

		}
		 return carobj;
				
					}

	static byte[] getImage(String name) throws IOException {
		// byte[] bytes = Files.readAllBytes(f.toPath());
		// InputStream is = new ByteArrayInputStream(bytes)

		storage = new FirebaseInitializer().getStorage();
		Blob blob = storage.get("gcpwebapp", name.toLowerCase()+".jpg");
//		InputStream in = blob.getBinaryStream();  
//		BufferedImage image = ImageIO.read(in);
		// Image image = null;

		byte[] b = null;
		ReadChannel reader;
		if (blob != null) {
			reader = blob.reader();
			InputStream inputStream = Channels.newInputStream(reader);
			OutputStream out = new FileOutputStream("./src/main/resources/static/downloadcarimages/"+name+".jpg");
			IOUtils.copy(inputStream, out);


			// image = ImageIO.read(inputStream);
			return IOUtils.toByteArray(inputStream);

		}

		return b;

	}

	/*
	 * @RequestMapping(value="getcarslist", method = RequestMethod.GET)
	 * public @ResponseBody String getMaruti(@RequestParam("company") String
	 * companyName) throws InterruptedException, ExecutionException { List<Car>
	 * carList = new ArrayList<Car>(); CollectionReference car=
	 * db.getFirebase().collection("Car"); ApiFuture<QuerySnapshot> querySnapshot=
	 * car.get(); for(DocumentSnapshot doc:querySnapshot.get().getDocuments()) { Car
	 * emp = doc.toObject(Car.class); carList.add(emp); } return "Hello Rajashekar";
	 * }
	 */

}
