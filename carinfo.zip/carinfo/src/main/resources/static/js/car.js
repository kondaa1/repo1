 function display(input) {  
	 var color;	 
	 var req = new XMLHttpRequest();
	 req.overrideMimeType("application/json");
	 req.open('GET', "/getcarinfo?name=s-cross", true);
	 req.onload  = function() {
	    var jsonResponse = JSON.parse(req.responseText);
	    
         color = jsonResponse.color;
         model = jsonResponse.model;
         mileage = jsonResponse.mileage;
         name = jsonResponse.name;
	 };
	 req.send(null);
}  
